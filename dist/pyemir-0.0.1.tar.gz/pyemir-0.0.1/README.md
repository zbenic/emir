Class Emir used for controlling the FMENA eMIR robot.

Setup:
- clone the repository
- cd to emir dir
- pip install ./dist/pyemir-0.0.1-py3-none-any.whl